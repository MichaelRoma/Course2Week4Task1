//
//  RadioViewController.swift
//  Course2Week4Task1
//
//  Copyright © 2018 e-Legion. All rights reserved.
//

import UIKit

class RadioViewController: UIViewController {
    
    
    private var compactRegularConstraints: [NSLayoutConstraint] = []
    private var compactCompactConstraints: [NSLayoutConstraint] = []
    
    private lazy var containerView: UIView = {
        let container = UIView()
        container.translatesAutoresizingMaskIntoConstraints = false
        return container
    }()
    
    private lazy var  imageView: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "coverImage.png")
        image.translatesAutoresizingMaskIntoConstraints = false
        image.contentMode = .scaleAspectFill
        image.layer.masksToBounds = true
        return image
    }()
    
    private lazy var progressView: UIProgressView = {
        let progress = UIProgressView()
        progress.translatesAutoresizingMaskIntoConstraints = false
        progress.progress = 0.5
        return progress
    }()
   
    private lazy var textView: UILabel = {
        let label = UILabel()
        label.translatesAutoresizingMaskIntoConstraints = false
        label.font = UIFont.systemFont(ofSize: 22, weight: .medium)
        label.textColor = .black
        label.textAlignment = .center
        label.numberOfLines = 1
        label.text = "Aerosmith - Hole Im My Soul"
        return label
    }()
    
    private lazy var mySlider: UISlider = {
        let slider = UISlider()
        slider.translatesAutoresizingMaskIntoConstraints = false
        slider.value = 0.5
        return slider
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addSubview(imageView)
        self.view.addSubview(containerView)
        containerView.addSubview(textView)
        containerView.addSubview(progressView)
        containerView.addSubview(mySlider)
        setupConstraints()
        NSLayoutConstraint.activate(compactRegularConstraints)
        layoutTrait(traitCollection: UIScreen.main.traitCollection)

    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        layoutTrait(traitCollection: traitCollection)

    }
    
    func setupConstraints() {
        compactRegularConstraints.append(contentsOf: [
            imageView.heightAnchor.constraint(equalToConstant: view.frame.width),
            imageView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 8),
            imageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            imageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),  containerView.topAnchor.constraint(equalTo: imageView.bottomAnchor, constant: 30),
            containerView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            containerView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
            containerView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -24),
            progressView.topAnchor.constraint(equalTo: containerView.topAnchor, constant: 0),
            progressView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 0),
            progressView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: 0),
            textView.bottomAnchor.constraint(equalTo: containerView.centerYAnchor),
            textView.centerXAnchor.constraint(equalTo: containerView.centerXAnchor),
            mySlider.heightAnchor.constraint(equalToConstant: 31),
            mySlider.bottomAnchor.constraint(equalTo: containerView.bottomAnchor, constant: 0),
            mySlider.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 0),
            mySlider.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: 0)
                
        ])
        
        compactCompactConstraints.append(contentsOf: [
           progressView.heightAnchor.constraint(equalToConstant: 2),
            progressView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            progressView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 16),
            progressView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -16),
            containerView.topAnchor.constraint(equalTo: progressView.bottomAnchor, constant: 16),
            containerView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -16),
            containerView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -71),
            containerView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 16),
            mySlider.heightAnchor.constraint(equalToConstant: 31),
            mySlider.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 16),
            mySlider.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -16),
            mySlider.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -24),
            imageView.heightAnchor.constraint(equalTo: containerView.heightAnchor),
            imageView.widthAnchor.constraint(equalTo: imageView.heightAnchor),
            imageView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor, constant: 0),
            textView.centerYAnchor.constraint(equalTo: containerView.centerYAnchor),
            textView.leadingAnchor.constraint(equalTo: imageView.trailingAnchor, constant: 16),           textView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor, constant: 0)
        ])
    }
    
    func layoutTrait(traitCollection:UITraitCollection) {
        if traitCollection.horizontalSizeClass == .compact && traitCollection.verticalSizeClass == .regular {
            guard !compactRegularConstraints[0].isActive else {return}
                    imageView.removeFromSuperview()
                    progressView.removeFromSuperview()
                    mySlider.removeFromSuperview()
                    self.view.addSubview(imageView)
                    self.view.addSubview(containerView)
                    containerView.addSubview(textView)
                    containerView.addSubview(progressView)
                    containerView.addSubview(mySlider)
            NSLayoutConstraint.deactivate(compactCompactConstraints)
            NSLayoutConstraint.activate(compactRegularConstraints)
                
        } else {
                progressView.removeFromSuperview()
                mySlider.removeFromSuperview()
                imageView.removeFromSuperview()
                self.view.addSubview(progressView)
                self.view.addSubview(mySlider)
                containerView.addSubview(imageView)
                NSLayoutConstraint.deactivate(compactRegularConstraints)
                NSLayoutConstraint.activate(compactCompactConstraints)
        }
    }
}



